# IdentifyNewBikes
hackathon project
Problem Statement : Identify New Bikes

PROBLEM STATEMENT:

Display upcoming bikes details like , bike name, its price and expected launch date in India
1. Manufacturer should be Honda.
2. Bike price should be less than 4Lac
(Suggested site: zigwheels however you are free to use any legitimate site)
Detailed Description: Hackath Ideas


Detailed Description: Hackath Ideas

1. Display "Upcoming" bikes details like bike name, price and expected launch date in India, for manufacturer 'Honda' & Bike price should be less than 4Lac.
2. For Used cars in Chennai, extract all the popular models in a List; Display the same
3. Try to 'Login' with google, give invalid account details & capture the error message
(Suggested site: zigwheels.com however you are free to use any legitimate site)
Key Automation Scope


Key Automation Scope:

Handling windows & frames
Filling simple form, Capture warning message
Extract menu items from frames & store in collections
Navigating back to home page





GROUP NO- 4
Group member(Names and employee id)
* ARPIT SAHU - 2153859  
* SOURAV RAWAT - 2153338 
* AKASH MONDAL - 2151527
* ARYAN SINGH- 2147337  
* RAJAT GAUTAM - 2149441 
* NAGA RANI MADDALA -2151229